create function date_out(date) returns cstring
    language internal
as
$$
date_out
$$;

comment on function date_out(date) is 'I/O';

