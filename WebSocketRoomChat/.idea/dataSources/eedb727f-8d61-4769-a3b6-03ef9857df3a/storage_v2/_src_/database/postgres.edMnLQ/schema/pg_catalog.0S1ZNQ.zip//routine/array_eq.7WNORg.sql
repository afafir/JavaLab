create function array_eq(anyarray, anyarray) returns boolean
    language internal
as
$$
array_eq
$$;

comment on function array_eq(anyarray, anyarray) is 'implementation of = operator';

