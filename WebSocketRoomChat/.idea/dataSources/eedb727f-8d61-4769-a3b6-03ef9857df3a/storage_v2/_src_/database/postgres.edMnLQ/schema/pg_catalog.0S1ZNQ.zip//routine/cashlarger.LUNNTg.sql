create function cashlarger(money, money) returns money
    language internal
as
$$
cashlarger
$$;

comment on function cashlarger(money, money) is 'larger of two';

