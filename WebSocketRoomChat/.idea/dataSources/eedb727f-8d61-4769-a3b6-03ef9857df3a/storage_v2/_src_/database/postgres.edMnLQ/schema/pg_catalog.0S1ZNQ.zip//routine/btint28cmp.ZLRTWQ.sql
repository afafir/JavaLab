create function btint28cmp(smallint, bigint) returns integer
    language internal
as
$$
btint28cmp
$$;

comment on function btint28cmp(int2, int8) is 'less-equal-greater';

