create function date_le_timestamp(date, timestamp without time zone) returns boolean
    language internal
as
$$
date_le_timestamp
$$;

comment on function date_le_timestamp(date, timestamp) is 'implementation of <= operator';

