create function btint24cmp(smallint, integer) returns integer
    language internal
as
$$
btint24cmp
$$;

comment on function btint24cmp(int2, int4) is 'less-equal-greater';

