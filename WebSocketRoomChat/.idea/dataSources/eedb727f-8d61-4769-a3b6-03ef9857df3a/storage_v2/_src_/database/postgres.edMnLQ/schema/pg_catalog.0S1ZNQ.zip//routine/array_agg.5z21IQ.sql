create function array_agg(anyarray) returns anyarray
    language internal
as
$$
aggregate_dummy
$$;

comment on function array_agg(anyarray) is 'concatenate aggregate input into an array';

