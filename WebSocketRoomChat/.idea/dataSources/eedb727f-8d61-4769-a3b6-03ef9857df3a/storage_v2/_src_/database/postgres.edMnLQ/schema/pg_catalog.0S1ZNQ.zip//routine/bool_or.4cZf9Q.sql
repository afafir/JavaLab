create function bool_or(boolean) returns boolean
    language internal
as
$$
aggregate_dummy
$$;

comment on function bool_or(bool) is 'boolean-or aggregate';

