create function array_lt(anyarray, anyarray) returns boolean
    language internal
as
$$
array_lt
$$;

comment on function array_lt(anyarray, anyarray) is 'implementation of < operator';

