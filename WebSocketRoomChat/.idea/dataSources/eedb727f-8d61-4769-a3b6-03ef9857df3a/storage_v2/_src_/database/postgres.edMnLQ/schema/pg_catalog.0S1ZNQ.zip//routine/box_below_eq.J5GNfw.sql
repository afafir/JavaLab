create function box_below_eq(box, box) returns boolean
    language internal
as
$$
box_below_eq
$$;

comment on function box_below_eq(box, box) is 'implementation of <^ operator';

