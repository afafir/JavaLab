create function btint2cmp(smallint, smallint) returns integer
    language internal
as
$$
btint2cmp
$$;

comment on function btint2cmp(int2, int2) is 'less-equal-greater';

