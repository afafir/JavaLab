create function bit_or(smallint) returns smallint
    language internal
as
$$
aggregate_dummy
$$;

comment on function bit_or(bit) is 'bitwise-or bit aggregate';

