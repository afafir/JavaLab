create function array_append(anyarray, anyelement) returns anyarray
    language internal
as
$$
array_append
$$;

comment on function array_append(anyarray, anyelement) is 'append element onto end of array';

