create function avg(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function avg(numeric) is 'the average (arithmetic mean) as numeric of all numeric values';

