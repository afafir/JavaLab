create function bitne(bit, bit) returns boolean
    language internal
as
$$
bitne
$$;

comment on function bitne(bit, bit) is 'implementation of <> operator';

