create function "RI_FKey_setnull_del"() returns trigger
    language internal
as
$$
RI_FKey_setnull_del
$$;

comment on function "RI_FKey_setnull_del"() is 'referential integrity ON DELETE SET NULL';

