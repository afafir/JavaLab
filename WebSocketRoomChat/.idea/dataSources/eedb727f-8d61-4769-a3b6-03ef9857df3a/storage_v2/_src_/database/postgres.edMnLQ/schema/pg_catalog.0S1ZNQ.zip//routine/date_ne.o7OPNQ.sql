create function date_ne(date, date) returns boolean
    language internal
as
$$
date_ne
$$;

comment on function date_ne(date, date) is 'implementation of <> operator';

