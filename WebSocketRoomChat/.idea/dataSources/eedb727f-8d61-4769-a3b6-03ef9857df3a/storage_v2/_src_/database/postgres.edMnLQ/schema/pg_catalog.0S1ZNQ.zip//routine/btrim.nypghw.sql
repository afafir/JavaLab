create function btrim(text, text) returns text
    language internal
as
$$
btrim
$$;

comment on function btrim(text, text) is 'trim selected characters from both ends of string';

