create function box_right(box, box) returns boolean
    language internal
as
$$
box_right
$$;

comment on function box_right(box, box) is 'implementation of >> operator';

