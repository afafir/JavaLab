create function bpcharlt(character, character) returns boolean
    language internal
as
$$
bpcharlt
$$;

comment on function bpcharlt(bpchar, bpchar) is 'implementation of < operator';

