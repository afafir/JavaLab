create function circle_div_pt(circle, point) returns circle
    language internal
as
$$
circle_div_pt
$$;

comment on function circle_div_pt(circle, point) is 'implementation of / operator';

