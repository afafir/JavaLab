create function cidsend(cid) returns bytea
    language internal
as
$$
cidsend
$$;

comment on function cidsend(cid) is 'I/O';

